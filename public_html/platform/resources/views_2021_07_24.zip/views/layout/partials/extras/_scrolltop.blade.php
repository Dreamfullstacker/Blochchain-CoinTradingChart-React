{{-- Scrolltop --}}
<div id="kt_scrolltop" class="scrolltop">
	{{ Metronic::getSVG("media/svg/icons/Navigation/Up-2.svg") }}
	{{-- <i class="fa fa-arrow-up"></i> --}}
</div>
